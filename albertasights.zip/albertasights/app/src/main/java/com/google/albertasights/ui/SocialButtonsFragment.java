package com.google.albertasights.ui;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.albertasights.R;
import com.squareup.picasso.Picasso;

public class SocialButtonsFragment extends Fragment {
    private static final String TAG = SocialButtonsFragment.class.getSimpleName();

    private MapViewModel viewModel;
    private Integer screenH;
    private Integer screenW;
    private String orientation;

    public SocialButtonsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "enter onCreateView");
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_social_buttons, container, false);
        viewModel = ViewModelProviders.of(getActivity()).get(MapViewModel.class);
        screenW = viewModel.getWight().getValue();
        screenH = viewModel.getHight().getValue();
        orientation = viewModel.getOrienr().getValue();

        ViewGroup.LayoutParams lp = v.getLayoutParams();

        if (orientation.equals(UiUtils.LANDSCAPE)) {
            Log.i(TAG, getActivity().getClass().getCanonicalName());
            if (getActivity().getClass().getCanonicalName().contains("User")) {
                lp.width = screenW/100*80;
            }
        }

        ImageButton fb = v.findViewById(R.id.facebook_gr);
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent myWebLink = new Intent(android.content.Intent.ACTION_VIEW);
                    myWebLink.setData(Uri.parse("https://www.facebook.com/groups/1717083371714334/"));
                    getActivity().startActivity(myWebLink);
                } catch (Exception e) {
                    UiUtils.showToast(getActivity(), "Error, maybe no browsers have been installed");
                }

            }
        });
        fb.getBackground().setAlpha(0);
        ImageButton insta = v.findViewById(R.id.instagram_gr);
        insta.getBackground().setAlpha(0);
        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent myWebLink = new Intent(android.content.Intent.ACTION_VIEW);
                    myWebLink.setData(Uri.parse("https://www.instagram.com/weloveyoualberta/"));
                    getActivity().startActivity(myWebLink);
                } catch (Exception e) {
                    UiUtils.showToast(getActivity(), "Error, maybe no browsers have been installed");
                }

            }
        });
        int squareDiment=0;

        if (orientation.equals(UiUtils.LANDSCAPE)) {
            squareDiment=screenW/13;
        } else {
            squareDiment=screenH/13;
        }

        Picasso.with(getActivity())
                .load(R.raw.fb)
                .resize(squareDiment, squareDiment)
                .into(fb);

        Picasso.with(getActivity())
                .load(R.raw.inst)
                .resize(squareDiment, squareDiment)
                .into(insta);
        Log.d(TAG, "exit onCreateView");

        return v;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
