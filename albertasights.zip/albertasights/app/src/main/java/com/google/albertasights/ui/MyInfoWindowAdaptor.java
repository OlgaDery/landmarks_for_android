package com.google.albertasights.ui;

import com.google.albertasights.R;
import com.google.albertasights.models.Place;
import com.google.android.gms.maps.GoogleMap;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.maps.model.Marker;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.Set;

/**
 * Created by olga on 2/13/18.
 */

public class MyInfoWindowAdaptor implements GoogleMap.InfoWindowAdapter {
    private TextView name;
    private TextView descr;
    private ImageView photo;
    private Context context;
    private Set<Place> places;
    private String orientation;
    private String deviceType;
    private String toLoad;
    private int screenWight;
    private int screenHight;
    int count = 0;
    private static final String TAG = "MyInfoWindowAdaptor";

    public MyInfoWindowAdaptor (Context context1, Set<Place> places1, String orient, String device, int hight, int wight) {
        this.context = context1;
        this.places= places1;
        this.orientation=orient;
        this.deviceType=device;
        this.screenHight = hight;
        this.screenWight = wight;
    }

    @Override
    public View getInfoWindow(Marker marker) {

        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        View v;

        try{
            if (orientation.equals(UiUtils.PORTRAIT)) {
                v = LayoutInflater.from(context).inflate(R.layout.custom_info_contents, null);

            } else {
                v = LayoutInflater.from(context).inflate(R.layout.custom_info_contents1, null);
            }

            photo = v.findViewById(R.id.img);
            descr = v.findViewById(R.id.descript);
            name = v.findViewById(R.id.name);

            ImageButton button = v.findViewById(R.id.more);
            button.setImageResource(R.drawable.more_horizontal);
            if (orientation.equals(UiUtils.PORTRAIT)) {

                if (deviceType.equals(UiUtils.TABLET)) {
                    // big vertical
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(screenWight/2, ViewGroup.LayoutParams.WRAP_CONTENT);
                    v.setLayoutParams(params);
                    RelativeLayout.LayoutParams photoParams = new RelativeLayout.LayoutParams(screenWight/2-20, screenHight/3-50);
                    photo.setLayoutParams(photoParams);
                } else {
                    // small vertical
                   LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(screenWight/100*70, ViewGroup.LayoutParams.WRAP_CONTENT);//screenHight/100*70
                   v.setLayoutParams(params);
                   RelativeLayout.LayoutParams photoParams = new RelativeLayout.LayoutParams(screenWight/100*70-20, screenHight/3);
                   photo.setLayoutParams(photoParams);

                }
            } else {
                //  v = LayoutInflater.from(context).inflate(R.layout.custom_info_contents1, null);

                if (deviceType.equals(UiUtils.TABLET)) {
//                    //TODO big horizontal
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(screenWight/2, ViewGroup.LayoutParams.WRAP_CONTENT);
                    v.setLayoutParams(params);
                    RelativeLayout.LayoutParams photoParams = new RelativeLayout.LayoutParams(screenWight/4, screenWight/4);
                    photo.setLayoutParams(photoParams);

                } else {
                    //TODO small horizontal
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(screenWight/100*60, ViewGroup.LayoutParams.WRAP_CONTENT);//screenHight/100*70
                    v.setLayoutParams(params);
                    RelativeLayout.LayoutParams photoParams = new RelativeLayout.LayoutParams(screenWight/4, screenHight/2-20);
                    photo.setLayoutParams(photoParams);
                }
            }

            if (deviceType.equals(UiUtils.TABLET)) {
                descr.setTextSize(context.getResources().getDimension(R.dimen.avg_textsize));
                name.setTextSize(context.getResources().getDimension(R.dimen.big_textsize));
                v.setPadding(30, 30, 30, 30);
            }

            //TODO setting up the content
            for (Place p: places) {
                if (p.getName().equals(marker.getTitle())) {
                    name.setText(p.getName());
                    //TODO!!
                    String newDescr;
                    if (p.getDescript().length() > 100) {
                        newDescr = p.getDescript().substring(0, 100);
                    } else {
                        newDescr = p.getDescript();
                    }
                    descr.setText(newDescr + "...");

                    // to get a link
                    if (!MapFragment.markerIds.contains(marker.getTitle())) {
                        if (p.getPhotoLink()!=null && p.getPhotoLink().length()>5)
                        {
                            Picasso.with(context)
                                    .load(UiUtils.parseUrl(p.getPhotoLink()))
                                    .resize(photo.getLayoutParams().width, photo.getLayoutParams().height)
                                    .centerCrop()
                                    .into(photo);

                        } else
                        {
                            Picasso.with(context)
                                    .load(R.drawable.no_ph)
                                    .into(photo);
                        }

                        toLoad= null;
                        count = 0;
                    } else {
                        // not_first_time_showing_info_window = true;
                        count++;
                        if (toLoad==null) {
                            if (!UiUtils.parseUrl(p.getPhotoLink()).equals("no")) {

                                toLoad = "url";

                            } else {
                                toLoad = "photo";

                            }
                        }
                        loadPicasso(UiUtils.parseUrl(p.getPhotoLink()), marker, photo);

                        break;
                    }

                }
            }

    //   Log.d(TAG, "exit getInfoContents(Marker marker)");

            return v;
        } catch (Exception e){
            e.printStackTrace();
           // Log.e(TAG, e.);
            toLoad=null;
            return null;
        }

    }

    private void loadPicasso (String url, Marker marker, ImageView photo) {
        if (this.toLoad.equals("url")) {
            Picasso.with(context)
                    .load(url)
                    .resize(photo.getLayoutParams().width, photo.getLayoutParams().height)//, )
                    .centerCrop()
                    .into(photo, new InfoWindowRefresher(marker));
            //   Log.i(TAG, "id removed: "+ )) ;

        } else {
            Picasso.with(context)
                    .load(R.drawable.no_ph)
                    .into(photo, new InfoWindowRefresher(marker));
            //    Log.i(TAG, "id removed: "+ MapsActivity.markerIds.remove(marker.getTitle())) ;

        }
    }

    private class InfoWindowRefresher implements Callback {

        private Marker markerToRefresh;

        private InfoWindowRefresher(Marker markerToRefresh) {
            this.markerToRefresh = markerToRefresh;
        }

        @Override
        public void onSuccess() {
            MapFragment.markerIds.remove(markerToRefresh.getTitle());
            if (count>2) {
                count=0;
                return;
            }
            markerToRefresh.showInfoWindow();

        }

        @Override
        public void onError() {
            toLoad = "photo";

            if (count>2) {
                count=0;
                return;
            }
            markerToRefresh.showInfoWindow();

        }
    }
}
