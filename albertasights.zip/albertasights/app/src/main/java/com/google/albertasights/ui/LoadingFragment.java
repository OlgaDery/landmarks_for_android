package com.google.albertasights.ui;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.google.albertasights.R;
import com.squareup.picasso.Picasso;


public class LoadingFragment extends Fragment {

    private MapViewModel viewModel;
    private Integer screenH;
    private Integer screenW;
    private String orientation;

    private OnRetryConnectionListener mListener;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_loading, container, false);
        viewModel = ViewModelProviders.of(getActivity()).get(MapViewModel.class);
        screenW = viewModel.getWight().getValue();
        screenH = viewModel.getHight().getValue();
        orientation = viewModel.getOrienr().getValue();

        final Button btn = v.findViewById(R.id.retry);
        ImageView img = v.findViewById(R.id.img);
        ViewGroup.LayoutParams params = img.getLayoutParams();
        params.height=screenH/100*80;
        params.width = screenW/100*80;
        if (orientation.equals(UiUtils.PORTRAIT)) {
            try {
                Picasso.with(getActivity())
                        .load(R.raw.albertasights_vertical)
                        .resize(screenW/100*80, screenH/100*80)
                        //    .onlyScaleDown()
                        .centerInside()
                        .into(img);
            } catch (Exception e) {
                Log.e(LoadingFragment.class.getCanonicalName(), e.toString());
            }


        } else {
            try {
                Picasso.with(getActivity())
                        .load(R.raw.albertasights_horizontal)
                        .resize(screenW/100*80, screenH/100*80)
                        //    .onlyScaleDown()
                        .centerInside()
                        .into(img);
            } catch (Exception e) {
                Log.e(LoadingFragment.class.getCanonicalName(), e.toString());
            }

        }
        btn.setAlpha(0.0f);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onButtonPressed("RETRY");
            }
        });

        final Observer<Boolean> loadingDataObserver = new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable final Boolean data) {
                if (data==false) {
                    showButton(btn);
                }
            }

        };
        viewModel.getDataReceived().observe(getActivity(), loadingDataObserver);
        return v;
    }

    public void onButtonPressed(String action) {
        if (mListener != null) {
            mListener.onRetryConnection(action);
        }
    }

    @Override
    public void onAttach(Context context) {
        System.out.println("!!!!!!!!!!!!!!!!!");
        super.onAttach(context);

        if (context instanceof OnRetryConnectionListener) {
            mListener = (OnRetryConnectionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private void showButton (Button btn) {
        btn.setAlpha(1.0f);
    }

    public interface OnRetryConnectionListener {
        void onRetryConnection(String action);
    }
}
